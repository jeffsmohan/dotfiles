#include QMK_KEYBOARD_H
#include "version.h"
#define MOON_LED_LEVEL LED_LEVEL
#ifndef ZSA_SAFE_RANGE
#define ZSA_SAFE_RANGE SAFE_RANGE
#endif

enum custom_keycodes {
  RGB_SLD = ZSA_SAFE_RANGE,
};



#define DUAL_FUNC_0 LT(3, KC_W)
#define DUAL_FUNC_1 LT(2, KC_F1)

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
  [0] = LAYOUT_moonlander(
    KC_GRAVE,       KC_1,           KC_2,           KC_3,           KC_4,           KC_5,           KC_6,                                           KC_5,           KC_6,           KC_7,           KC_8,           KC_9,           KC_0,           KC_MINUS,       
    KC_TAB,         KC_Q,           KC_W,           KC_E,           KC_R,           KC_T,           KC_NO,                                          KC_NO,          KC_Y,           KC_U,           KC_I,           KC_O,           KC_P,           KC_EQUAL,       
    DUAL_FUNC_0,    LT(1, KC_A),    KC_S,           KC_D,           KC_F,           KC_G,           KC_NO,                                                                          KC_NO,          KC_H,           KC_J,           KC_K,           KC_L,           LT(2, KC_SCLN), KC_QUOTE,       
    KC_LEFT_SHIFT,  MT(MOD_LCTL, KC_Z),KC_X,           KC_C,           KC_V,           KC_B,                                           KC_N,           KC_M,           KC_COMMA,       KC_DOT,         KC_SLASH,       KC_RIGHT_SHIFT, 
    KC_LEFT_CTRL,   KC_LEFT_ALT,    KC_LEFT_GUI,    KC_LEFT,        KC_RIGHT,       KC_BSLS,                                                                                                        KC_ESCAPE,      KC_UP,          KC_DOWN,        KC_RIGHT_GUI,   KC_RIGHT_ALT,   KC_RIGHT_CTRL,  
    KC_ENTER,       KC_LEFT_GUI,    DUAL_FUNC_1,                    KC_BSPC,        KC_BSPC,        KC_SPACE
  ),
  [1] = LAYOUT_moonlander(
    KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT,                                 KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_SLASH,       KC_ASTR,        KC_MINUS,       KC_TRANSPARENT, 
    KC_TRANSPARENT, KC_TRANSPARENT, KC_BSLS,        KC_LCBR,        KC_RCBR,        KC_PIPE,        KC_TRANSPARENT,                                 KC_TRANSPARENT, KC_TRANSPARENT, KC_7,           KC_8,           KC_9,           KC_PLUS,        KC_TRANSPARENT, 
    KC_TRANSPARENT, KC_TRANSPARENT, KC_HASH,        KC_LPRN,        KC_RPRN,        KC_MINUS,       KC_TRANSPARENT,                                                                 KC_TRANSPARENT, KC_TRANSPARENT, KC_4,           KC_5,           KC_6,           KC_TRANSPARENT, KC_TRANSPARENT, 
    KC_TRANSPARENT, KC_TRANSPARENT, KC_GRAVE,       KC_LBRC,        KC_RBRC,        KC_UNDS,                                        KC_TRANSPARENT, KC_1,           KC_2,           KC_3,           KC_TRANSPARENT, KC_TRANSPARENT, 
    KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT,                                                                                                 KC_TRANSPARENT, KC_0,           KC_0,           KC_DOT,         KC_ENTER,       KC_TRANSPARENT, 
    KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT,                 KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT
  ),
  [2] = LAYOUT_moonlander(
    KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT,                                 KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, RGB_TOG,        
    KC_TRANSPARENT, LGUI(LCTL(KC_Q)),KC_TRANSPARENT, LALT(LGUI(KC_UP)),KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT,                                 KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_UP,          KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, 
    KC_TRANSPARENT, KC_TRANSPARENT, LALT(LGUI(KC_LEFT)),LALT(LGUI(KC_DOWN)),LALT(LGUI(KC_RIGHT)),KC_TRANSPARENT, KC_TRANSPARENT,                                                                 KC_TRANSPARENT, KC_TRANSPARENT, KC_LEFT,        KC_DOWN,        KC_RIGHT,       KC_TRANSPARENT, KC_TRANSPARENT, 
    KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT,                                 KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, 
    KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT,                                                                                                 KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT, 
    KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT,                 KC_TRANSPARENT, KC_TRANSPARENT, KC_TRANSPARENT
  ),
};





extern rgb_config_t rgb_matrix_config;

RGB hsv_to_rgb_with_value(HSV hsv) {
  RGB rgb = hsv_to_rgb( hsv );
  float f = (float)rgb_matrix_config.hsv.v / UINT8_MAX;
  return (RGB){ f * rgb.r, f * rgb.g, f * rgb.b };
}

void keyboard_post_init_user(void) {
  rgb_matrix_enable();
}

const uint8_t PROGMEM ledmap[][RGB_MATRIX_LED_COUNT][3] = {
    [1] = { {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239}, {152,221,239} },

    [2] = { {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206}, {89,225,206} },

};

void set_layer_color(int layer) {
  for (int i = 0; i < RGB_MATRIX_LED_COUNT; i++) {
    HSV hsv = {
      .h = pgm_read_byte(&ledmap[layer][i][0]),
      .s = pgm_read_byte(&ledmap[layer][i][1]),
      .v = pgm_read_byte(&ledmap[layer][i][2]),
    };
    if (!hsv.h && !hsv.s && !hsv.v) {
        rgb_matrix_set_color( i, 0, 0, 0 );
    } else {
        RGB rgb = hsv_to_rgb_with_value(hsv);
        rgb_matrix_set_color(i, rgb.r, rgb.g, rgb.b);
    }
  }
}

bool rgb_matrix_indicators_user(void) {
  if (rawhid_state.rgb_control) {
      return false;
  }
  if (!keyboard_config.disable_layer_led) { 
    switch (biton32(layer_state)) {
      case 1:
        set_layer_color(1);
        break;
      case 2:
        set_layer_color(2);
        break;
     default:
        if (rgb_matrix_get_flags() == LED_FLAG_NONE) {
          rgb_matrix_set_color_all(0, 0, 0);
        }
    }
  } else {
    if (rgb_matrix_get_flags() == LED_FLAG_NONE) {
      rgb_matrix_set_color_all(0, 0, 0);
    }
  }

  return true;
}




bool process_record_user(uint16_t keycode, keyrecord_t *record) {
  switch (keycode) {

    case DUAL_FUNC_0:
      if (record->tap.count > 0) {
        if (record->event.pressed) {
          register_code16(LCTL(KC_SPACE));
        } else {
          unregister_code16(LCTL(KC_SPACE));
        }
      } else {
        if (record->event.pressed) {
          register_code16(KC_LEFT_CTRL);
        } else {
          unregister_code16(KC_LEFT_CTRL);
        }  
      }  
      return false;
    case DUAL_FUNC_1:
      if (record->tap.count > 0) {
        if (record->event.pressed) {
          register_code16(LCTL(KC_SPACE));
        } else {
          unregister_code16(LCTL(KC_SPACE));
        }
      } else {
        if (record->event.pressed) {
          register_code16(KC_LEFT_GUI);
        } else {
          unregister_code16(KC_LEFT_GUI);
        }  
      }  
      return false;
    case RGB_SLD:
        if (rawhid_state.rgb_control) {
            return false;
        }
        if (record->event.pressed) {
            rgblight_mode(1);
        }
        return false;
  }
  return true;
}

